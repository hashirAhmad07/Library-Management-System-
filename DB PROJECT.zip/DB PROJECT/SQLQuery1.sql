USE[LMS];

-----------------ADMINISTRATOR TABLE-----------------

Create Table Administrator(
	ID int IDENTITY(1,1) NOT NULL,
	UserName varchar(30),
	Password varchar(20),
	age int,
	Email varchar(50),
	Phone_No varchar(25)
	PRIMARY KEY(ID)
);

Insert into Administrator(UserName,Password,age,Email,Phone_No)
values
('Hashir',123,20,'F2020065186@umt.edu.pk',03342404165),
('Maheen',123,20,'F2020065192@umt.edu.pk',03249214952);

SELECT * FROM Administrator;

DROP TABLE Administrator;
--------------CATEGORY TABLE LMS-----------

create table Category(
ID int IDENTITY(1,1) NOT NULL,
Category_Name varchar(50),
Status varchar(50),
Primary key(ID)
);



insert into Category(Category_Name,Status)
values('History','Available'),
('Mathematics','Available'),
('Statistics','Available'),
('Ethics','Available'),
('Physics','Unavailable'),
('Designing','Available'),
('Astronomy','Available'),
('Chemistry','Available'),
('Geology','Unavailable'),
('Economics','Unavailable');

Drop table Category

SELECT * FROM Category;

---------------------Author Table ----------------------

Create Table Author
(
	ID int identity(1,1) NOT NULL,
	Author_Name varchar(20),
	Address varchar(20),
	Phone varchar(25)
	PRIMARY KEY (ID)
);


INSERT INTO Author(Author_Name,Address,Phone)
VALUES
('James F. Brennan','NewYork',222233345671),
('Ron Larson','London',33523456678),
('Ali','Pakistan',44456732145),
('Eleanor','America',55543256789),
('Cather','America',634526784532),
('JK Rowling','ScotLand',723547865324),
('Suresh Raina','India',84567265356),
('Amrita Pritam','India',9995323347384),
('E.M Foster','America',2345343746873),
('Clarke','America',1143678939555);

Select * From Author;

drop table Author;
--------------------PUBLISHER TABLE-------------

Create Table Publisher
(
	ID int identity(1,1) NOT NULL,
	Publisher_Name varchar(50),
	Address varchar(20),
	Phone varchar(15),
	PRIMARY KEY(ID)
);

insert into Publisher(Publisher_Name,Address,Phone)
values('Saunders College Pub', 'Lahore',03005634567),
('Prentice-Hall', 'Lahore',03005634567),
('McGraw-Hill Humanities', 'Faisalabad',0300566432),
('Barnes & Noble', 'Gujranwala',03005343556),
('Thomson Wadsworth', 'Peshawar',030034242355),
('Barnes & Noble', 'Lahore',0302557547),
('Brown & Benchmark Publishers', 'Islamabad',032245556567),
('Addison-Wesley', 'Quetta',03205634567),
('Wiley', 'Karachi',03335634567),
('Pan Publishing', 'Lahore',03004354567);

Select * from Publisher;

DROP TABLE Publisher;


-------------------BOOK TABLE------------------------

Create Table Book
(
	ID int identity(1,1) NOT NULL,
	Book_Name varchar(60),
	Category int,
	Author int,
	Publisher int,
	Content varchar(20),
	Quantity int,
	Edition int,	
	PRIMARY KEY(ID)
);

Insert into Book(Book_Name,Category,Author,Publisher,Content,Quantity,Edition)
values('History and systems of psychology',1,1,1,'History',365,2),
('Algebra 1',2,2,2,'Mathematics',400,1),
('Statistical techniques',3,3,3,'Statistics',200,2),
('Contemporary moral issues',4,4,4,'Ethics',300,5),
('Physical chemistry',5,5,5,'Physics',400,5),
('Architecture',6,6,6,'Designing',200,6),
('The new astronomy',7,7,7,'Astronomy',300,4),
('Organic chemistry',8,8,8,'Chemistry',600,2),
('An Introduction to Physical Geology',9,9,9,'Geology',350,6),
('Introduction to Economics',10,10,10,'Economics',275,1);

---JOIN QUERY
Select b.ID, b.Book_name, c.Category_Name, a.Author_Name, p.Publisher_Name, b.Content, b.Quantity, b.Edition From Book b 
JOIN Category c ON b.Category = c.ID 
JOIN Author a ON b.Author = a.ID 
JOIN Publisher p ON b.Publisher = p.ID;


Select * from Book;

Drop Table Book;

--------------------------MEMBER TABLE--------------------------

Create Table Member
(
	ID int identity(1,1) NOT NULL,
	Member_Name varchar(20),
	S_ID varchar(15),
	Address varchar(20),
	Phone varchar(25),
	Email varchar(50)
	PRIMARY KEY(ID)
);

INSERT INTO Member(Member_Name,S_ID,Address,Phone,Email)
VALUES
('Ali Ahmad','F2020065101','Johar Town lahore',03334567891,'F2020065101@umt.edu.pk'),
('Asim Raza','F2020065102','Wapda Town Lahore',03352345668,'F2020065102@umt.edu.pk'),
('Shazil Ali','F2020065103','Wapda Town Lahore',44456732145,'F2020065103@umt.edu.pk'),
('Taha Shehbaz','F2020065104','Model Town Lahore',55543256789,'F2020065104@umt.edu.pk'),
('Aliya butt','F2020065105','DHA phase-1',634526784532,'F2020065105@umt.edu.pk'),
('Myra khan','F2020065106','DHA phase-2',723547865324,'F2020065106@umt.edu.pk'),
('Suresh Raina','F2020065107','Quetta pakistan',84567265356,'F2020065107@umt.edu.pk'),
('Amrita Pritam','F2020065108','Model Town Lahore',9995323347384,'F2020065108@umt.edu.pk'),
('Sehrish Mukhtar','F2020065109','Model Town Lahore',2345343746873,'F2020065109@umt.edu.pk'),
('Sundas Raza','F2020065110','Johar Town Lahore',1143678939555,'F2020065110@umt.edu.pk');



Drop Table Member;

Select * FRom Member;



-------------------------ISSUE TABLE---------------------------------------

Create Table IssueBook
(
	ID int identity(1,1) NOT NULL,
	MemberID int, 
	BookID int,
	PersonIs varchar(10),
	IssueDate DATE,
	ReturnDate DATE,
	PRIMARY KEY(ID)
);

Drop Table IssueBook;

Select * FRom IssueBook;

Select i.id, m.Member_name, b.Book_Name,i.PersonIs, i.IssueDate,i.ReturnDate From IssueBook i JOIN Member m ON i.MemberID=m.id JOIN Book b ON i.BookId = b.id;

-----------------RETURN TABLE--------------------


select m.Member_Name, b.Book_Name, i.ReturnDate,DATEDIFF(day,i.IssueDate,i.ReturnDate) AS Elapse From  IssueBook i JOIN Member m ON i.MemberID = m.ID JOIN Book b ON i.BookID = b.ID;

--------------------------RETURN TABLE--------------

Create Table ReturnBook
(
	ID int IDENTITY(1,1) NOT NULL,
	MemberID int,
	MemberName varchar(50),
	BookName varchar(50),
	ReturnDate varchar(50),
	Days_Elapse int,
	Fine int,
	PersonIs varchar(10),
	PRIMARY KEY(ID)
);

Select * FRom ReturnBook;

Drop Table ReturnBook;
-------------DEPARTMENT TABLE------------------

create Table Department(
D_id int NOT NULL,
degree varchar(10)
PRIMARY KEY (D_id)
);

INSERT INTO Department(d_id, degree)
VALUES(1,'SE'),
(2, 'IT'),
(3,'HS'),
(4,'AI'),
(5,'BIO_ TECH'),
(6,'LITRATURE'),
(7,'PHYSICS'),
(8,'CHEMISTRY'),
(9,'CIVIL_ENGG'),
(10,'SHS');

SELECT * FROM Department;


-------------------------STUDENT TABLE-----------------------
create Table Student
(
	S_ID varchar(20) NOT NULL UNIQUE,
	age int,
	Name varchar(20),
	Email varchar(30),
	PRIMARY KEY(S_ID),
	D_ID INT FOREIGN KEY REFERENCES Department(D_ID)
);


Insert into Student(S_ID,age,Name,Email,D_id)
values('F2020065256',20,'Myra Khan','F2020065256@umt.edu.pk',1),
('F2020065192',20,'Maheen Hammad','F2020065192@umt.edu.pk',2),
('F2020065190',19,'Khadija Saif','F2020065190@umt.edu.pk',2),
('F2020065208',20,'Nooriya Maqsood','F2020065208@umt.edu.pk',3),
('F2020065220',20,'Habiba Afzal','F2020065220@umt.edu.pk',5),
('F2020065025',20,'Habib Rehman','F2020065025@umt.edu.pk',6),
('F2020065193',20,'Fazal A Rabi','F2020065193@umt.edu.pk',7),
('F2020065258',20,'Myra Khan','F2020065258@umt.edu.pk',1),
('F2020065019',20,'Maheen Hammad','F2020065193@umt.edu.pk',2),
('F2020065186',20,'Hashir Ahmad','F2020065186@umt.edu.pk',1),
('F2020065202',20,'Mateen Khan','F2020065202@umt.edu.pk',1);

Drop Table Student;

Select * From Student;

Select s.S_ID,s.age,s.F_name,s.L_Name,s.Email,d.degree As Degree From Student s JOIN  Department d ON  s.D_id = d.D_id;


--------------FUNCTIONAL DEPENDENCY AND NORMALIZATIO-------------------
create Table Std1
(
	S_ID varchar(20) NOT NULL UNIQUE,
	age int,
	Email varchar(30),
	D_ID INT FOREIGN KEY REFERENCES Department(D_ID),
	primary key(S_ID)
);

Insert into Std1(S_ID,age,Email,D_id)
values('F2020065256',20,'F2020065256@umt.edu.pk',1),
('F2020065192',20,'F2020065192@umt.edu.pk',2),
('F2020065190',19,'F2020065190@umt.edu.pk',2),
('F2020065208',20,'F2020065208@umt.edu.pk',3),
('F2020065220',20,'F2020065220@umt.edu.pk',5),
('F2020065025',20,'F2020065025@umt.edu.pk',6),
('F2020065193',20,'F2020065193@umt.edu.pk',7),
('F2020065258',20,'F2020065258@umt.edu.pk',1),
('F2020065019',20,'F2020065193@umt.edu.pk',2),
('F2020065186',20,'F2020065186@umt.edu.pk',1),
('F2020065202',20,'F2020065202@umt.edu.pk',1);


Select * from Std1;

drop table Std1;


create Table Std2
(
	Email varchar(30),
	D_ID INT FOREIGN KEY REFERENCES Department(D_ID),
	Primary key(Email)
);


Insert into Std2(Email,D_id)
values('F2020065256@umt.edu.pk',1),
('F2020065191@umt.edu.pk',2),
('F2020065190@umt.edu.pk',2),
('F2020065208@umt.edu.pk',3),
('F2020065220@umt.edu.pk',5),
('F2020065025@umt.edu.pk',6),
('F2020065193@umt.edu.pk',7),
('F2020065258@umt.edu.pk',1),
('F2020065194@umt.edu.pk',2),
('F2020065186@umt.edu.pk',1),
('F2020065202@umt.edu.pk',1);

Select * from Std2;

drop table Std2;






-----------FACULTY TABLE---------------------------------
CREATE TABLE Faculty
(
	ID int IDENTITY(1,1) NOT NULL,
	D_id INT FOREIGN KEY REFERENCES Department(D_ID)

);

DROP TABLE FACULTY;

SELECT * FROM FACULTY;
--- USE OF ALTER COMMAND-----
ALTER TABLE FACULTY 
ADD F_Name varchar(20);

Select * FRom Faculty;

---INSERT IN FACULTY

Insert INTO Faculty VALUES(1,'Ali hamza'),
(2,'Ahmad shehzad'),
(3,'Ahmad Ali'),
(2,'Usman sarfraz'),
(2,'Gull Imran'),
(2,'Myra Khan'),
(2,'MAteen Khan');


--------------REPORT TABLE--------------

CREATE TABLE Report
(
	ID int IDENTITY(1,1) NOT NULL,
	UserName varchar(50),
	Return_Date DATE,
	Fine int,
	BookName varchar(50),
	A_id int FOREiGN KEY REFERENCES Administrator(A_id)
);



---------------------------	WHERE CLAUSE AND ORDER CLAUSE--------------------------
 SELECT * FROM STUDENT;

 Select * From Student 
 where S_ID = 'F2020065192';

 Select * FRom Student 
 Order by S_ID ASC;
 

 ---------JOIN QUERIES------------

 --INNER JOIN
 
Select s.S_ID,s.age,s.F_name,s.L_Name,s.Email,d.degree As Degree From Student s JOIN  Department d ON  s.D_id = d.D_id;

Select b.ID, b.Book_name, c.Category_Name, a.Author_Name, p.Publisher_Name, b.Content, b.Quantity, b.Edition From Book b 
JOIN Category c ON b.Category = c.ID 
JOIN Author a ON b.Author = a.ID 
JOIN Publisher p ON b.Publisher = p.ID;

--LEFT OUTER JOIN

SELECT s.S_ID, s.F_Name, d.degree FROM Student s
LEFT OUTER JOIN Department d ON s.D_id = d.D_id;

--RIGHT OUTER JOIN

SELECT s.S_ID, s.F_Name, d.degree FROM Student s
RIGHT OUTER JOIN Department d ON s.D_id = d.D_id;

--CROSS JOIN

SELECT s.S_ID, s.F_Name, d.degree FROM Student s
CROSS JOIN Department d;

--SELF JOIN

SELECT F1.F_Name FROM Faculty F1 , Faculty F2
WHERE F1.ID = F2.D_id;

SELECT * froM Faculty;

------------------------------------------------------------------------------------------

---------------------------------- VIEWS -----------------------

CREATE VIEW Student_View
AS 
Select *  From Student 
where S_ID like '%F2020065%';

Select F_name,Email From Student_View;
Select S_id,F_name,age From Student_View;

Drop view Student_View;

-----------------------PROCEDURES--------------------

CREATE PROCEDURE P_STUDENT 
AS
SELECT * FROM Student
Go;

EXEC P_STUDENT;

CREATE PROCEDURE P_STUDENT2
@Name varchar(30), @Em varchar(30) 
AS
SELECT * FROM Student where Name  = @Name AND  Email = @Em
Go;

EXEC P_STUDENT2 @Name = 'MAheen hammad' , @Em = 'F2020065192@umt.edu.pk';

drop procedure P_STUDENT2;

SELECT * FROM Student