
import Library.Category;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Hashir Ahmad
 */
public class TestExec {

    public static void main(String[] args) {
        Connection con = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String dbURL = "jdbc:sqlserver://localhost:1433;DatabaseName=hello;encrypt=true;trustServerCertificate=true;user=sa;password=1234;";

            con = DriverManager.getConnection(dbURL);
            System.out.println("Database Connected");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Category.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            System.out.println("Database NOT Connected");
            Logger.getLogger(Category.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (null == con) {
            System.out.println("Not Connected...");
        } else {
            System.out.println("Connected...");
        }
    }

}
